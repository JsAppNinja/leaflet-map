<?php
/*
  Plugin name: Custom Leaflet Map
  Plugin URI: http://PLUGIN_URI.com/
  Description: Custom Leaflet Map
  Author: Connor Barrett
  Author URI: http://AUTHOR_URI.com
  Version: 1.0
*/

$leagues;
$programs;
$league_type = 'current';

require_once( plugin_dir_path( __FILE__ ) . 'functions.php' );

add_action('wp_enqueue_scripts', 'league_load_scripts');
function league_load_scripts($hook) {
  wp_enqueue_script('datatables', '//cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js', array(), '3', true);
  wp_enqueue_script('league-script', plugin_dir_url( __FILE__ ) . 'assets/script.js', array(), '3', true);
  wp_enqueue_script('poper', '//cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js', array(), '3', true);
  wp_enqueue_script('share-prompt', '//cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.js', array(), '3', true);
  wp_enqueue_script('select2_script', "//cdnjs.cloudflare.com/ajax/libs/select2/4.0.10/js/select2.min.js", array(), '3', true);
  wp_enqueue_script('datepicker', plugin_dir_url( __FILE__ ) . 'assets/datepicker/datepicker.min.js', array(), '3', true);
  wp_enqueue_script('datepicker-en', plugin_dir_url( __FILE__ ) . 'assets/datepicker/i18n/datepicker.en.js', array(), '3', true);  
  
  wp_enqueue_style('select2_style', "//cdnjs.cloudflare.com/ajax/libs/select2/4.0.10/css/select2.min.css");
  wp_enqueue_style('datatables-style', '//cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css');
  wp_enqueue_style('share-style', '//cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.css');
  wp_enqueue_style('league-style', plugin_dir_url( __FILE__ ) . 'assets/style.css' );
  wp_enqueue_style('datepicker-css', plugin_dir_url( __FILE__ ) . 'assets/datepicker/datepicker.min.css', array());
}

////////////////////////////////////////
////////    common function     ////////
////////////////////////////////////////

function print_button_group() {
?>
    <div id="currentLeagueButtons">
      <input type="button" id="current-button" value="Current" class="league-selected-button"/>
      <input type="button" id="open-button" value="Open" class="league-deselected-button right-button">
    </div>
<?php
}

function renderSocialIcon() {
  echo('
    <i class="nycbbl-icon share-icon">
      <svg width="14px" height="14px" viewBox="0 0 14 14" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
      <g id="Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
          <g id="card-selected" transform="translate(-331.000000, -219.000000)" fill="#E5590C" fill-rule="nonzero">
              <g id="Group-6">
                  <g id="Group-3" transform="translate(284.000000, 216.000000)">
                      <g id="share-alt" transform="translate(47.000000, 3.000000)">
                          <path d="M10.8181818,8.27272727 C10.056879,8.27776178 9.33779644,8.62329495 8.85818182,9.21454545 L5.61272727,7.71909091 C5.76531967,7.25183961 5.76531967,6.74816039 5.61272727,6.28090909 L8.85818182,4.78545455 C9.64858025,5.73921867 11.0108073,5.98552963 12.0851494,5.36893839 C13.1594915,4.75234715 13.6339923,3.4518931 13.20919,2.28830437 C12.7843878,1.12471563 11.5836322,0.435863084 10.3647309,0.656487698 C9.14582957,0.877112311 8.26271442,1.94315139 8.27272727,3.18181818 C8.27464129,3.33342024 8.28954431,3.48457939 8.31727273,3.63363636 L4.95727273,5.18 C3.95742963,4.20235698 2.3561508,4.21434111 1.37105244,5.20683964 C0.385954076,6.19933816 0.385954076,7.80066184 1.37105244,8.79316036 C2.3561508,9.78565889 3.95742963,9.79764302 4.95727273,8.82 L8.31727273,10.3663636 C8.28954431,10.5154206 8.27464129,10.6665798 8.27272727,10.8181818 C8.27272727,12.2239975 9.41236609,13.3636364 10.8181818,13.3636364 C12.2239975,13.3636364 13.3636364,12.2239975 13.3636364,10.8181818 C13.3636364,9.41236609 12.2239975,8.27272727 10.8181818,8.27272727 Z M10.8181818,1.90909091 C11.5210897,1.90909091 12.0909091,2.47891032 12.0909091,3.18181818 C12.0909091,3.88472605 11.5210897,4.45454545 10.8181818,4.45454545 C10.115274,4.45454545 9.54545455,3.88472605 9.54545455,3.18181818 C9.54545455,2.47891032 10.115274,1.90909091 10.8181818,1.90909091 Z M3.18181818,8.27272727 C2.47891032,8.27272727 1.90909091,7.70290786 1.90909091,7 C1.90909091,6.29709214 2.47891032,5.72727273 3.18181818,5.72727273 C3.88472605,5.72727273 4.45454545,6.29709214 4.45454545,7 C4.45454545,7.70290786 3.88472605,8.27272727 3.18181818,8.27272727 Z M10.8181818,12.0909091 C10.115274,12.0909091 9.54545455,11.5210897 9.54545455,10.8181818 C9.54545455,10.115274 10.115274,9.54545455 10.8181818,9.54545455 C11.5210897,9.54545455 12.0909091,10.115274 12.0909091,10.8181818 C12.0909091,11.5210897 11.5210897,12.0909091 10.8181818,12.0909091 Z" id="Shape"></path>
                      </g>
                  </g>
              </g>
          </g>
      </g>
      </svg>
    </i>
  ');
}

function renderBasketballIcon() {
  echo ('
    <i class="nycbbl-icon basketball-icon">
      <svg width="19px" height="19px" viewBox="0 0 19 19" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
        <g id="Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
            <g id="card-ongoing-" transform="translate(-30.000000, -29.000000)" fill="#E55608" fill-rule="nonzero">
                <g id="Group-6">
                    <g id="basketball" transform="translate(30.000000, 29.000000)">
                        <path d="M9.5,-4.4408921e-16 C6.27191585,0.00330210067 3.26639275,1.6456058 1.52,4.3605 L1.52,4.3605 C-0.976278042,8.27539977 -0.277037924,13.4211106 3.17340615,16.5279224 C6.62385023,19.6347343 11.8144619,19.7923006 15.447,16.9005 L15.447,16.9005 C18.5844636,14.3751324 19.7885335,10.1458377 18.451659,6.346637 C17.1147845,2.54743625 13.527548,0.00412128144 9.5,-4.4408921e-16 Z M11.4,2.147 C14.0733571,2.8390036 16.1609964,4.92664288 16.853,7.6 C15.2645869,7.64473483 13.7141923,8.09611554 12.35,8.911 C11.6649739,8.13388576 10.9008492,7.43025431 10.07,6.8115 C10.9070795,5.39691061 11.3651661,3.79033557 11.4,2.147 Z M9.5,1.9 C9.49687402,3.26327504 9.12247332,4.59995124 8.417,5.7665 C8.2745,5.6905 8.1415,5.605 7.999,5.5385 C6.77574509,4.89306034 5.46775659,4.422952 4.1135,4.142 C5.53920496,2.70778629 7.47772337,1.90092501 9.5,1.9 Z M2.85,5.852 C4.33999729,6.05898615 5.78304453,6.52178972 7.1155,7.22 L7.239,7.296 C5.82284127,8.71083135 3.90180879,9.50385544 1.9,9.50001399 C1.90528264,8.22351503 2.23199932,6.96892298 2.85,5.852 Z M7.6,16.853 C4.92664288,16.1609964 2.8390036,14.0733571 2.147,11.4 C4.71100601,11.3430695 7.14055842,10.2415352 8.873,8.3505 C9.5597669,8.85817515 10.1960381,9.43081926 10.773,10.0605 C8.82887911,11.7939421 7.68176513,14.2495903 7.6,16.853 L7.6,16.853 Z M9.5,17.1000104 C9.50414337,14.9902387 10.3850907,12.9771364 11.932,11.5425 C11.989,11.6185 12.046,11.685 12.0935,11.761 C12.8895964,12.9800647 13.4801187,14.3215774 13.8415,15.732 C12.5700125,16.6247574 11.0536054,17.102575 9.5,17.1000104 Z M15.3995,14.25 C14.9869472,12.9931501 14.4120904,11.7955319 13.6895,10.6875 L13.49,10.45 C14.5945804,9.83549636 15.8360241,9.50880064 17.1,9.5 C17.0905785,11.2307752 16.490672,12.9064915 15.3995,14.25 Z" id="Shape"></path>
                    </g>
                </g>
            </g>
        </g>
      </svg>
    </i>
  ');
}

function renderUntickIcon() {
  echo('
    <i class="nycbbl-icon untick-icon">
      <svg width="20px" height="21px" viewBox="0 0 20 21" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
      <g id="Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" opacity="0.471540179">
          <g id="card" transform="translate(-323.000000, -28.000000)" fill="#B6B6B6" fill-rule="nonzero">
              <g id="check-circle-(1)" transform="translate(323.000000, 28.500000)">
                  <path d="M12.72,6.79 L8.43,11.09 L6.78,9.44 C6.53561012,9.15462384 6.1518816,9.03031806 5.78658103,9.11818987 C5.42128045,9.20606167 5.13606167,9.49128045 5.04818987,9.85658103 C4.96031806,10.2218816 5.08462384,10.6056101 5.37,10.85 L7.72,13.21 C7.90871883,13.3971865 8.16419702,13.5015368 8.43,13.5000167 C8.69233988,13.4988954 8.94373936,13.3947442 9.13,13.21 L14.13,8.21 C14.3193127,8.0222334 14.4257983,7.76663754 14.4257983,7.5 C14.4257983,7.23336246 14.3193127,6.9777666 14.13,6.79 C13.7399625,6.40227641 13.1100375,6.40227641 12.72,6.79 L12.72,6.79 Z M10,-4.4408921e-16 C4.4771525,-4.4408921e-16 1.77635684e-15,4.4771525 1.77635684e-15,10 C1.77635684e-15,15.5228475 4.4771525,20 10,20 C15.5228475,20 20,15.5228475 20,10 C20,7.3478351 18.9464316,4.80429597 17.0710678,2.92893219 C15.195704,1.0535684 12.6521649,-4.4408921e-16 10,-4.4408921e-16 Z M10,18 C5.581722,18 2,14.418278 2,10 C2,5.581722 5.581722,2 10,2 C14.418278,2 18,5.581722 18,10 C18,12.1217319 17.1571453,14.1565632 15.6568542,15.6568542 C14.1565632,17.1571453 12.1217319,18 10,18 Z" id="Shape"></path>
              </g>
          </g>
      </g>
      </svg>
    </i>
  ');
}

function renderTickIcon() {
  echo('
    <svg width="20px" height="21px" viewBox="0 0 20 21" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
        <g id="card-selected" transform="translate(-323.000000, -28.000000)" fill="#4CB7B7" fill-rule="nonzero">
            <g id="check-circle-(1)" transform="translate(323.000000, 28.500000)">
                <path d="M12.72,6.79 L8.43,11.09 L6.78,9.44 C6.53561012,9.15462384 6.1518816,9.03031806 5.78658103,9.11818987 C5.42128045,9.20606167 5.13606167,9.49128045 5.04818987,9.85658103 C4.96031806,10.2218816 5.08462384,10.6056101 5.37,10.85 L7.72,13.21 C7.90871883,13.3971865 8.16419702,13.5015368 8.43,13.5000167 C8.69233988,13.4988954 8.94373936,13.3947442 9.13,13.21 L14.13,8.21 C14.3193127,8.0222334 14.4257983,7.76663754 14.4257983,7.5 C14.4257983,7.23336246 14.3193127,6.9777666 14.13,6.79 C13.7399625,6.40227641 13.1100375,6.40227641 12.72,6.79 L12.72,6.79 Z M10,-4.4408921e-16 C4.4771525,-4.4408921e-16 1.77635684e-15,4.4771525 1.77635684e-15,10 C1.77635684e-15,15.5228475 4.4771525,20 10,20 C15.5228475,20 20,15.5228475 20,10 C20,7.3478351 18.9464316,4.80429597 17.0710678,2.92893219 C15.195704,1.0535684 12.6521649,-4.4408921e-16 10,-4.4408921e-16 Z M10,18 C5.581722,18 2,14.418278 2,10 C2,5.581722 5.581722,2 10,2 C14.418278,2 18,5.581722 18,10 C18,12.1217319 17.1571453,14.1565632 15.6568542,15.6568542 C14.1565632,17.1571453 12.1217319,18 10,18 Z" id="Shape"></path>
            </g>
        </g>
    </g>
    </svg>
  ');
}

////////////////////////////////////////
////////     render league      ////////
////////////////////////////////////////

function render_current_leagues_header() {
?>
  <thead style="background-color: #EFF3F6 !important;">
    <tr class="current">
      <td class="blank-header"></td>
      <td>Sports</td>
      <td>Day</td>
      <td>League</td>
      <td>Neighborhood</td>
      <td>Gender</td>
      <td>Start Date</td>
      <td>Time</td>
      <td>Team</td>
      <td>Free Agent</td>
      <td class="blank-header"></td>
    </tr>
  </thead>
<?php
}

function render_open_leagues_header() {
?>
  <thead style="background-color: #EFF3F6 !important;">
    <tr class="open">
      <td class="blank-header"></td>
      <td>Sports</td>
      <td>Day</td>
      <td>League</td>
      <td>Neighborhood</td>
      <td>Gender</td>
      <td>Start Date</td>
      <td>Time</td>
      <td>Team</td>
      <td>Free Agent</td>
      <td class="blank-header"></td>
    </tr>
  </thead>
<?php
}

function print_program_table_head() {
?>
  <thead style="background-color: #EFF3F6;">
    <tr>
      <td class="blank-header"></td>
      <td>Sports</td>
      <td>Day</td>
      <td>Program</td>
      <td>Location</td>
      <td>Neighborhood</td>
      <td>Start Date</td>
      <td>Time</td>
      <td class="blank-header"></td>
    </tr>
  </thead>
<?php
}

function render_open_league_table_body() {
  global $leagues;

  echo ('<tbody>');
  foreach ($leagues as $league) {
    if (is_array($league->neighborhood)) {
      $neighborhoods = array_map("nycbbl_neighborhoods_string", $league->neighborhood);
    } else {
      $neighborhoods = array();
    }
?>
    <tr class="open">
      <td class="right-border"><input type="checkbox"></td>
      <td><?php echo($league->name); ?></td>
      <td><?php echo(date("D", strtotime($league->start_date)));?></td>
      <td><?php echo($league->name); ?></td>
      <td class="td_neighborhood"><?php echo implode(", ", $neighborhoods); ?></td>
      <td>Men's</td>
      <td class="td_startdate"><?php echo(date("m/d/y", strtotime($league->start_date)));?></td>
      <td> - </td>
      <td><?php echo($league->team_price[0]); ?></td>
      <td><?php echo($league->free_agent_price[0]); ?></td>
      <td class="nycbbl_actions">
        <a class="league-button" href="/signup/new_team/?selected_season=<?php echo($league->id) ?>">Info</a>
        <a class="league-button">Wishlist</a>
        <span class="dropdown league-register-desktop">
          <a class="league-button dropdown-button" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Register</a>
          <span class="dropdown-menu">
            <a class="dropdown-item" href="/signup/new_team/?selected_season=<?php echo $league->id ?>">Team</a>
            <a class="dropdown-item" href="/signup/free_agent/?selected_season=<?php echo $league->id ?>">Free Agency</a>
          </span>
        </span>
        <a class="share-by-email" onclick="window.open('mailto:your@email.address?subject=Share by Email');">share by email <?php renderSocialIcon() ?></a>
      </td>      
    </tr>
<?php
  }
  echo ('</tbody>');
}

function render_current_league_table_body() {
  global $leagues;
  foreach ($leagues as $league) {
    if (is_array($league->neighborhood)) {
      $neighborhoods = array_map("nycbbl_neighborhoods_string", $league->neighborhood);
    } else {
      $neighborhoods = array();
    }
?>
    <tr class="current">
      <td class="right-border"><input type="checkbox"></td>
      <td><?php echo($league->name); ?></td>
      <td><?php echo(date("D", strtotime($league->start_date)));?></td>
      <td><?php echo($league->name); ?></td>
      <td class="td_neighborhood"><?php echo implode(", ", $neighborhoods); ?></td>        
      <td>Men's</td>
      <td class="td_startdate"><?php echo(date("m/d/y", strtotime($league->start_date)));?></td>
      <td> - </td>
      <td><?php echo($league->team_price[0]); ?></td>
      <td><?php echo($league->free_agent_price[0]); ?></td>
      <td class="current nycbbl_actions">
        <a class="league-button" href="/division/all_divisions/?selected_season=<?php echo($league->id) ?>">Schedule ></a><a class="league-button" href="/division/all_divisions/?selected_season=<?php echo($league->id) ?>">Standing ></a>
        <a class="share-by-email" onclick="window.open('mailto:your@email.address?subject=Share by Email');">share by email <?php renderSocialIcon() ?></a>
      </td>      
    </tr>
<?php
  }
}

function print_program_table_body() {
  global $programs;
  foreach ($programs as $program) {

    if (is_array($program->neighborhood)) {
      $neighborhoods = array_map("nycbbl_neighborhoods_string", $program->neighborhood);
    } else {
      $neighborhoods = array();
    }
?>
    <tr>
      <td class="right-border"><input type="checkbox"></td>
      <td><?php echo($program->title); ?></td>
      <td><?php echo(date("D", strtotime($program->start_time)));?></td>
      <td><?php echo($program->title); ?></td>
      <td><?php echo($program->location_summary); ?></td>
      <td class="td_neighborhood"><?php echo implode(", ", $neighborhoods); ?></td>
      <td class="td_startdate"><?php echo(date("m/d/y", strtotime($program->start_time)));?></td>
      <td><?php echo(date("h-m A", strtotime($program->start_time)));?></td>
      <td class="nycbbl_actions">
        <div class="current">
          <a class="league-button" href="/programs/register/<?php echo($program->class_package_group->slug) ?>">Schedule ></a>
          <a class="league-button" href="<?php echo($program->class_package_group->slug) ?>">Info</a>
        </div>
        <div class="open">
          <a class="league-button" href="#">Info</a>
          <a class="league-button" href="/programs/classes/pre_registration/?class_package=<?php echo($program->id) ?>">Whitelist</a>
          <a class="league-button" href="/programs/camp_registration/?class_package=<?php echo($program->id) ?>">Register</a>
        </div>
        <a class="share-by-email" onclick="window.open('mailto:your@email.address?subject=Share by Email');">share by email <?php renderSocialIcon() ?></a>
      </td>
    </tr>
<?php 
  }
}

function get_leagues_data() {
  global $leagues;
  $response =  wp_remote_get(get_option('api_url').get_option('league_path').'?limit=1000', array('timeout' => 20));
  $body = json_decode(wp_remote_retrieve_body($response));
  $leagues = $body->results;
}

function nycbbl_dropdown_group() {
  global $leagues, $programs;

  $league_neighborhoods = nycbbl_get_all_neighborhoods($leagues, "league");
  $program_neighborhoods = nycbbl_get_all_neighborhoods($programs, "programs");
?>
    <div class="league-dropdown-group">
      <div class="nycbbl-filters">
        <div class="nycbbl-filter"><input type="text" class="league-search-text" id="league-search-text" placeholder="Search" /></div>
        <div class="nycbbl-filter">
          <select class="league-select single" id="sport_type">
            <option value="">Sport (any)</option>
            <option value="basketball">Bascketball</option>
            <option value="kickball">Kickball</option>
          </select>
        </div>
        <div class="nycbbl-filter">
          <select class="league-select single" id="league_type">
            <option value="league">League</option>
            <option value="program">Program</option>
          </select>
        </div>
        <div class="nycbbl-filter league_neighborhood_filter">
          <select class="league-select multiple league_filter" multiple="multiple" id="league_neighborhoods" placeholder="Neighborhood (any)">
            <option value="">Neighborhood (any)</option>
            <?php foreach ($league_neighborhoods as $id => $name) : ?>
              <option value="<?= $name ?>" key="<?= $id ?>"><?= $name ?></option>
            <?php endforeach ?>
          </select>
        </div>
        <div class="nycbbl-filter program_neighborhood_filter">          
          <select class="league-select multiple program_filter" multiple="multiple" id="program_neighborhoods">
            <option value="">Neighborhood (any)</option>
            <?php foreach ($program_neighborhoods as $id => $name) : ?>
              <option value="<?= $name ?>" key="<?= $id ?>"><?= $name ?></option>
            <?php endforeach ?>
          </select>
        </div>
        <div class="nycbbl-filter">
          <select class="league-select single">
            <option>Gender (any)</option>
            <option value="man">Men</option>
            <option value="">Women</option>
          </select>
        </div>
        <div class="nycbbl-filter">
          <input type='text' id="filter-datepicker" placeholder="Start Date (any)"/>
        </div>
        <div class="nycbbl-filter" style="display: none;">
          <button class="apply-button">Apply</button>
        </div>
      </div>
    </div>
<?php
}

function print_league_mobile_field() {
  echo '<div class="league-mobile-field">';
  
  global $leagues;
  foreach ($leagues as $league) {
    ?>
      <div class="d-flex flex-column nycbbl-mobile-item league-field">
        <div class="row mobile-item-header">
          <?php renderBasketballIcon() ?>
          <p class="sports-text"><?php echo($league->name); ?></p>
          <?php renderUntickIcon() ?>
        </div>
        <p>Starts: <?php echo(date("M. d, Y", strtotime($league->start_date)));?></p>
        <p>Ends: <?php echo(date("M. d, Y", strtotime($league->end_date)));?></p>
        <p>Early Signup Deadline: <?php echo(date("M. d, Y", strtotime($league->early_signup_deadline)));?></p>
        <p>Regular Signup Deadline: <?php echo(date("M. d, Y", strtotime($league->regular_signup_deadline)));?></p>
        <p>Team Price: $<?php echo join(" $", $league->team_price);?></p>
        <p style="margin-bottom: 16px;">Free Agency Price: $<?php echo join(" $", $league->free_agent_price);?></p>
        <div class="open mobile-actions">
          <div class="d-flex align-items-center" style="margin-bottom: 8px;">
            <a class="league-button league-info-mobile" href="/signup/new_team/?selected_season=<?php echo($league->id) ?>">Info</a>
            <a class="league-button league-wishlilst-mobile" href="/signup/new_team/?selected_season=<?php echo($league->id) ?>">Wishlist</a>
            <a class="share-link">share by text <?php renderSocialIcon() ?></a>
          </div>
          <div class="dropdown league-register-mobile">
            <a class="league-button dropdown-button" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Register</a>
            <div class="dropdown-menu">
              <a class="dropdown-item" href="/signup/new_team/?selected_season=<?php echo $league->id ?>">Team</a>
              <a class="dropdown-item" href="/signup/free_agent/?selected_season=<?php echo $league->id ?>">Free Agency</a>
            </div>
          </div>
        </div>
        <div class="current mobile-actions">
          <div class="d-flex align-items-center" style="margin-bottom: 8px;">
            <a class="league-button league-schedule-mobile" href="/division/all_divisions/?selected_season=<?php echo($league->id) ?>">Schedule ></a>
            <a class="share-link">share by text <?php renderSocialIcon() ?></a>
          </div>
          <div class="d-flex flex-row">
            <a class="league-button league-standing-mobile" href="/division/all_divisions/?selected_season=<?php echo($league->id) ?>">Standings ></a>
          </div>
        </div>
      </div>
    <?php
  }

  echo '</div>';  
}

function render_league_table() {  
  echo ('<div id="leagueTableDiv">');    
    echo('<table class="open" id="leagueTableOpen">');
    render_open_leagues_header();
    render_open_league_table_body();
    echo('</table>');

    echo('<table class="current" id="leagueTableCurrent">');
    render_current_leagues_header();
    render_current_league_table_body();
    echo('</table>');
    
    print_league_mobile_field();
  echo('</div>');
}

////////////////////////////////////////
////////     render program     ////////
////////////////////////////////////////

function get_programs_data() {
  global $programs;

  $response =  wp_remote_get(get_option('api_url').get_option('program_path').'?limit=1000', array('timeout' => 20));
  $body = json_decode(wp_remote_retrieve_body($response));
  $programs = $body->results;
}

function print_program_mobile_field() {
  global $programs;
  
  echo '<div class="program-mobile-field">';
    
    foreach ($programs as $program) {
      
      echo('<div class="d-flex flex-column nycbbl-mobile-item program-field">');
      if ($program->registration_open == true) {
        // echo("<div class='open mobile-item-border'>");
      } else {
        // echo("<div class='current mobile-item-border'>");
      }
      
      ?>
        <div class="row mobile-item-header">
          <?php renderBasketballIcon() ?>
          <p class="sports-text"><?php echo($program->title); ?></p>
          <?php renderUntickIcon() ?>
        </div>
        
        <p>Starts: <?php echo(date("M, d, y", strtotime($program->start_time)));?></p>
        <p>Time: <?php echo(date("M, d, y", strtotime($program->time_summary)));?></p>
        <p>Location: <?php echo($program->location_summary); ?></p>
        <p>Gender: Men's</p>
        <p style="margin-bottom: 16px;">Days: <?php echo(date("D", strtotime($program->start_time)));?></p>
        <div class="open mobile-actions">
          <div class="d-flex align-items-center" style="margin-bottom: 8px;">
            <a class="league-button program-info-mobile">Info</a>
            <a class="league-button program-wishlist-mobile" href="/programs/classes/pre_registration/?class_package=<?php echo $program->id?>">Wishlist</a>
            <a class="share-link">share by text <?php renderSocialIcon() ?></a>
          </div>
          <div class="d-flex flex-row">
            <a class="league-button program-register-mobile" href="/programs/classes/pre_registration/?class_package%5B%5D=<?php echo $program->id?>">Register</a>
          </div>
        </div>
        
        <div class="current mobile-actions">
          <div class="d-flex align-items-center" style="margin-bottom: 8px;">
            <a class="league-button" href="/programs/register/<?php echo $program->class_package_group->slug?>">Schedule ></a>
            <a class="share-link">share by text <?php renderSocialIcon() ?></a>
          </div>
          <div class="d-flex flex-row">
            <a class="league-button">Standings</a>
          </div>
        </div>
      <?php        

      echo ('</div>');
    }

  echo ('</div>');
}

function render_program_table() {
  echo '<div id="programTableDiv">';
    print_program_mobile_field();

    echo '<table id="programTable">';
      print_program_table_head();
      echo('<tbody>');
        print_program_table_body();
      echo('</tbody>');
    echo '</table>';
  echo '</div>';
}

add_shortcode( 'leagues', 'leagues_func' );
function leagues_func( $atts ) {
    ob_start();

    get_leagues_data();
    get_programs_data();

    $query_args = array(
			'post_type'      => 'unit',
			'posts_per_page' => 300,
    );

    $drafts = get_posts( $query_args );
    echo count($drafts);
    echo '<div class="league-plugin" style="visibility: hidden; height: 200px;">';
    echo '<div class="filters-wrap">';
      print_button_group();
      nycbbl_dropdown_group();
    echo '</div>';
    render_league_table();
    render_program_table();
    echo '</div>';

    $out = ob_get_clean();
    return $out;
};

function leagues_options_page() {
    require dirname( __FILE__ ) . '/tpl/options.php';
}

add_action('admin_menu', 'leagues_admin_menu', 12);
function leagues_admin_menu() {
    add_options_page(__('Leagues Configuration'), __('Leagues'), 'manage_options', 'leagues_options', 'leagues_options_page');
    register_setting( 'leagues_options', 'api_url' );
    register_setting( 'leagues_options', 'league_path' );
    register_setting( 'leagues_options', 'program_path' );
}