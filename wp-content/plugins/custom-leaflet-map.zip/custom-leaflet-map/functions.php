<?php

function nycbbl_get_all_neighborhoods($data, $type = 'league') {
  $results = [];

  if (empty($data)) return $results;

  foreach ($data as $d) {
    if (!empty($d->neighborhood)) {
      foreach ($d->neighborhood as $item) {
        if (!array_key_exists($item->id, $results)) {
          $results[$item->id] = $item->name;
        }
      }
    }
  }
  return $results;
}

function nycbbl_neighborhoods_string($el) {
  return $el->name;
}

?>