<div class="wrap">
    <h2>SocialRoot - ShopBop Plugin Settings</h2>
    <form method="post" action="options.php">
        <?php settings_fields('leagues_options'); ?>
        <?php $api_url = get_option('api_url'); ?>
        <?php $league_path = get_option('league_path'); ?>
        <?php $program_path = get_option('program_path'); ?>
        <table class="form-table">
            <tr valign="top">
                <th scope="row">
                    API URL
                </th>
                <td>
                    <input style="width: 400px;" name="api_url" type="text" value="<?=$api_url?>"/>
                </td>
            </tr>
            <tr valign="top">
                <th scope="row">
                    League Path
                </th>
                <td>
                    <input style="width: 400px;" name="league_path" type="text" value="<?=$league_path?>"/>
                </td>
            </tr>
            <tr valign="top">
                <th scope="row">
                    Program Path
                </th>
                <td>
                    <input style="width: 400px;" name="program_path" type="text" value="<?=$program_path?>"/>
                </td>
            </tr>
        </table>
        <p class="submit">
            <input type="submit" class="button-primary" value="<?php _e('Save Changes') ?>" />
        </p>
    </form>
</div>

<br/>
