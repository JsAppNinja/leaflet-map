jQuery(document).ready(function($) {
  var current = true;
  var api_type = 'league';

  Array.prototype.equals = function (array) {
    // if the other array is a falsy value, return
    if (!array)
      return false;

    // compare lengths - can save a lot of time 
    if (this.length != array.length)
      return false;

    for (var i = 0, l = this.length; i < l; i++) {
      // Check if we have nested arrays
      if (this[i] instanceof Array && array[i] instanceof Array) {
        // recurse into the nested arrays
        if (!this[i].equals(array[i]))
          return false;
      } else if (this[i] != array[i]) {
        // Warning - two different object instances will never be equal: {x:20} != {x:20}
        return false;
      }
    }
    return true;
  }
  // Hide method from for-in loops
  Object.defineProperty(Array.prototype, "equals", {
    enumerable: false
  });

  function nycbbl_has_neighborhood(master, search) {
    return search.some((i => v => i = master.indexOf(v, i) + 1)(0));
  }    
  
  $(document).on('input', '.league-search-text', function (e) {
    nycbbl_apply_filters();
  });

  $("#league_neighborhoods, #program_neighborhoods").change(function () {
    nycbbl_apply_filters();
  });

  $(document).on('change', '#filter-datepicker', function (e) {
    nycbbl_apply_filters();
  });

  function nycbbl_apply_filters() {
    var textFilter = $("#league-search-text").val().toLowerCase();      
    var neighborhoodFilter = $(`#${api_type}_neighborhoods`).val() || '';
    var dateFilter = $("#filter-datepicker").val();
    var searchCriteria = [textFilter != '', neighborhoodFilter != '', dateFilter != ''];
    var rowText = '', colText = '', rowCriteria;
    var $rows, $mobileRows; 
    
    console.log(api_type, "------", searchCriteria)
    if (api_type == "league") {
      current ? $rows = $(`#${api_type}TableCurrent`).find('tbody tr') : $rows = $(`#${api_type}TableOpen`).find('tbody tr');        
    } else {
      $rows = $(`#${api_type}Table`).find('tbody tr');
    }

    $mobileRows = $(`.${api_type}-mobile-field > .nycbbl-mobile-item`);
    
    $rows.each(function (i, e) {
      rowCriteria = [false, false, false];
      if (textFilter) {
        rowText = $(e).text().toLowerCase().trim();
        if (rowText.includes(textFilter)) {
          rowCriteria[0] = true;
        }
      }

      if (neighborhoodFilter) {
        colText = $(e).find(".td_neighborhood").text();
        if (colText) {
          var rowNeighborhood = colText.split(", ");
          rowCriteria[1] = nycbbl_has_neighborhood(rowNeighborhood, neighborhoodFilter);
        }
      }

      if (dateFilter) {
        colText = $(e).find(".td_startdate").text();
        if (colText.includes(dateFilter)) {
          rowCriteria[2] = true;
        }
      }
      
      if (rowCriteria.equals(searchCriteria)) {
        $(e).show();
        $mobileRows.eq(i).show();
      } else {
        $(e).hide();
        $mobileRows.eq(i).hide();
      }
    });
  }

  $("#open-button").click(function() {
    if (current == true) {
      $("#open-button").removeClass("league-deselected-button");
      $("#open-button").addClass("league-selected-button");
      $("#current-button").addClass("league-deselected-button");
      $("#current-button").removeClass("league-selected-button");
      $(".current").hide();
      $(".open").show();
      current = false;
      nycbbl_apply_filters();            
    }
  });

  $("#current-button").click(function () {
    if (current != true) {
      $("#current-button").removeClass("league-deselected-button");
      $("#current-button").addClass("league-selected-button");

      $("#open-button").addClass("league-deselected-button");
      $("#open-button").removeClass("league-selected-button");
      $(".open").hide();
      $(".current").show();
      current = true;
      nycbbl_apply_filters();
    }
  });

  $(".share-link").click(function () {
    $.confirm({
      title: '',
      content: '' +
      '<form action="" class="formName">' +
      '<div class="form-group">' +
      '<label>Name</label>' +
      '<input type="text" placeholder="name" class="name form-control" required />' +
      '</div>' +
      '<div class="form-group">' +
      '<label>message</label>' +
      '<textarea name="comment" placeholder="message" form="usrform" />' +
      '</div>' +
      '</form>',
      buttons: {
        formSubmit: {
          text: 'Share',
          btnClass: 'btn-blue',
          action: function () {
            var name = this.$content.find('.name').val();
            if(!name){
              $.alert('please input name to share');
              return false;
            }
          }
        },
        cancel: function () {
        },
      },
      onContentReady: function () {
        // bind to events
        var jc = this;
        this.$content.find('form').on('submit', function (e) {
          e.preventDefault();
          jc.$$formSubmit.trigger('click'); // reference the button and click it
        });
      }
    });
  });
  
  $(".league-select").select2({
      width: "100%"
  });
  $(".league-select.multiple").select2({
    width: "100%",
    placeholder: "Neighborhood (any)"
  });

  
  $leagueTableColumns = [{
    "searchable": false,
    "orderable": false,
    "width": "8px",
    "targets": 0
  }, {
    "searchable": false,
    "width": "80px",
    "targets": 1
  }, {
    "searchable": false,
    "width": "50px",
    "targets": 2
  }, {
    "searchable": false,
    "width": "100px",
    "targets": 3
  }, {
    "searchable": false,
    "width": "80px",
    "targets": 4
  }, {
    "searchable": false,
    "width": "50px",
    "targets": 5
  }, {
    "searchable": false,
    "width": "60px",
    "targets": 6
  }, {
    "searchable": false,
    "width": "60px",
    "targets": 7
  }, {
    "searchable": false,
    "width": "40px",
    "targets": 8
  }, {
    "searchable": false,
    "width": "60px",
    "targets": 9
  }, {
    "searchable": false,
    "width": "170px",
    "targets": 10
  }];

  $programTableColumns = [{
    "searchable": false,
    "orderable": false,
    "width": "8px",
    "targets": 0
  }, {
    "searchable": false,
    "width": "80px",
    "targets": 1
  }, {
    "searchable": false,
    "width": "50px",
    "targets": 2
  }, {
    "searchable": false,
    "width": "100px",
    "targets": 3
  }, {
    "searchable": false,
    "width": "100px",
    "targets": 4
  }, {
    "searchable": false,
    "width": "80px",
    "targets": 5
  }, {
    "searchable": false,
    "width": "60px",
    "targets": 6
  }, {
    "searchable": false,
    "width": "60px",
    "targets": 7
  }, {
    "searchable": false,
    "width": "140px",
    "targets": 8
  }];

  $('#leagueTableCurrent').DataTable(
    {
      "info": false,
      "searching": false,
      "paging": false,
      "columnDefs": $leagueTableColumns,
    }
  );
  
  $leagueTableColumns[10]["width"] = "200px";
  $('#leagueTableOpen').DataTable(
    {
      "info":     false,
      "searching": false,
      "paging":    false,
      "columnDefs": $leagueTableColumns,
    }
  );

  $('#programTable').DataTable(
    {
      "info":     false,
      "searching": false,
      "paging":    false,
      "columnDefs": $programTableColumns,
    }
  );

  $('#filter-datepicker').datepicker({
    language: 'en',
    position: 'bottom left',
    dateFormat: 'mm/dd/yy',
    onSelect: function onSelect(fd, date, inst) {
      inst.hide();
      nycbbl_apply_filters();
    }
  });

  $(".league-plugin").css( {"visibility": "visible", "height": "auto"} );
  $(".open").hide();
  $("#programTableDiv").hide();
  
  $("#league_type").change(function() {
    api_type = $("#league_type").val();
    if (api_type == 'program') {
      $('#leagueTableDiv').hide();
      $('#programTableDiv').show();
      $('.league_neighborhood_filter').hide();
      $('.program_neighborhood_filter').show();
    } else if (api_type == 'league') {
      $('#programTableDiv').hide();
      $('#leagueTableDiv').show();
      $('.program_neighborhood_filter').hide();
      $('.league_neighborhood_filter').show();
    }
    nycbbl_apply_filters();
  });

  $("#sport_type").change(function() {
    window.location.href = window.location.hostname + $("#sport_type").val();
    nycbbl_apply_filters();
  });

  $(".dropdown-button").click(function() {
    $(this).next(".dropdown-menu").toggleClass("show");
  });

  // Close the dropdown menu if the user clicks outside of it
  window.onclick = function (event) {
    if (!event.target.matches('.dropdown-button')) {
      var dropdowns = document.getElementsByClassName("dropdown-menu");
      var i;
      for (i = 0; i < dropdowns.length; i++) {
        var openDropdown = dropdowns[i];
        if (openDropdown.classList.contains('show')) {
          openDropdown.classList.remove('show');
        }
      }
    }
  }
});
function toggleLeague(value, $) {
  currentLeague = !value;
  if(!currentLeague) {
      document.getElementById("currentLeagueButtons").style.display = 'none';
      document.getElementById("openLeagueButtons").style.display = 'block';
      $(".current").hide();
      $(".open").show();
  } else {
      document.getElementById("currentLeagueButtons").style.display = 'block';
      document.getElementById("openLeagueButtons").style.display = 'none';
      $(".open").hide();
      $(".current").show();
  }
}

function openCloseFilter(startDate) {
  var currentTime = new Date().getTime();
  var _startDate = new Date(startDate).getTime();
  return currentLeague && currentTime > _startDate;

}
